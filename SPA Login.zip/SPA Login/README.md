# SinglePageApp-AngularJS-DotNet
An AngularJS SPA that uses adal.js to sign users in and make API calls.
